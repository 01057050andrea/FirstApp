import SwiftUI

struct ExtractedView: View {
    var body: some View {
        HStack(alignment: .bottom, spacing: 2.0){
            
            HStack(alignment: .bottom, spacing: 0.0){
                Text("能量")
                    .font(.footnote)
                    .fontWeight(.light)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
                
            }
            
            // 調整位置顏色
            .frame(width: 30.0, height: 28.0)
            .background(Color(red: 42/255, green: 42/255, blue: 45/255))
            
            .cornerRadius(30)
            .padding(.leading, 3.0)
            
        }
        //.opacity(0.8)
    }
}



