import SwiftUI

struct Extractedview3: View {
    var body: some View {
        HStack {
            VStack {
                Image(systemName: "house")
                    .foregroundColor(.white)
                Text("首頁")
                    .font(.footnote)
                    .fontWeight(.regular)
                    .foregroundColor(.white)
            }
        }
    }
}

