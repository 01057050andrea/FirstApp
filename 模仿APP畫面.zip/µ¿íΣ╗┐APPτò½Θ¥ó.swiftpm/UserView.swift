import SwiftUI

struct UserView: View {
    let name: String
    
    
    var body: some View {
        ZStack{
            Rectangle()
                .frame(width: 60.0, height: 33.0)
                .background(Color.white)
                .cornerRadius(/*@START_MENU_TOKEN@*/6.0/*@END_MENU_TOKEN@*/)
                .padding(.leading, 0)
                .opacity(0.2)
            HStack{
                Text(name)    
                    .font(.system(size: 15))
                    .fontWeight(.regular)
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
            }
        }
        .padding(1)
    }
}
        
        
                                 
