import SwiftUI

struct UserView2: View {
    let icon: String
    let name2: String
    let name3: String
    
    var body: some View {           
        
        HStack {
            Image(icon)
                .resizable()
                .scaledToFill()
                .frame(width: 50, height: 50)
               // .clipped()
                .padding(.leading, 10)
                .cornerRadius(5) 
                
            
            VStack(alignment: .leading, spacing: 4) {
                Text(name2)
                    .font(.system(size: 15))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                    
                Text(name3)
                    .font(.footnote)
                    .fontWeight(.regular)
                    .foregroundColor(.gray)
                    .padding(.leading, 0)
                
            }
            
            Spacer()
            Image(systemName: "ellipsis")
                .foregroundColor(.white)
                .rotationEffect(Angle.init(degrees: 90))
                .padding(.trailing, 720)
        }
    }
}

