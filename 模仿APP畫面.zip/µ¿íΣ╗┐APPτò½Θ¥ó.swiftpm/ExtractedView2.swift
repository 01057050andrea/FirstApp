import SwiftUI

struct ExtractedView2: View {
    var body: some View {
        HStack {
            Image("Tan")
                .resizable()
                .scaledToFill()
                .frame(width: 50, height: 50)
                .padding(.leading, 10)
                .cornerRadius(5) 
            
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Love Me Again")
                    .font(.system(size: 15))
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                
                Text("V")
                    .font(.footnote)
                    .fontWeight(.regular)
                    .foregroundColor(.gray)
                    .padding(.leading, 0)
                
            }
            
        
            Spacer()     
            Image(systemName: "ellipsis")
                .foregroundColor(.white)
                .rotationEffect(Angle.init(degrees: 90))
                .padding(.trailing, 740)
        }
    }
}

//Image(systemName: "backward.circle.fill")
//Image(systemName: "play.circle.fill")
  //  .symbolRenderingMode(.multicolor)
//Image(systemName: "ellipsis")
//Image(systemName: "forward.circle.fill")
  //  .symbolRenderingMode(.multicolor)
