import SwiftUI
struct UserView3: View {
    let icon2: String
    let name4: String
    
    var body: some View {
        HStack(spacing: 40) {
            VStack(spacing: 5) {
                Image(systemName: icon2)
                    .foregroundColor(.white)
                Text(name4)
                    .font(.footnote)
                    .fontWeight(.regular)
                    .foregroundColor(.white)

            }
        }
    }
}

