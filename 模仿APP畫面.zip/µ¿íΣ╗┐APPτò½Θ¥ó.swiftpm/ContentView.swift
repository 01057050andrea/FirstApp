import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {   
            
            VStack(alignment: .leading, spacing: 5) {
                
                VStack(spacing: 10) {         
                    
                    HStack(spacing: 1) {
                        Text("11:27")
                            .padding(.leading, 10)
                            .font(.footnote)
                            .fontWeight(.light)
                            .foregroundColor(.white)
                        //.padding(.trailing, 2.0)
                        
                        
                        Image(systemName: "music.note")
                            .foregroundColor(.white)
                            .padding(.trailing, 200)
                        Image(systemName: "wifi")
                            .foregroundColor(.white)
                        Image(systemName: "personalhotspot")
                            .foregroundColor(.white)
                        Text("93%")
                            .font(.footnote)
                            .fontWeight(.regular)
                            .foregroundColor(.white)
                        Image(systemName: "battery.75")
                            .foregroundColor(.white)
                    }
                    
                    HStack {
                        Image("Ytmusic")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 30, height: 30)
                            .mask(Circle())
                            .padding(.leading, -10)
                        Text("Music")
                            .font(.body)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        
                        
                        Image(systemName: "magnifyingglass")
                            .foregroundColor(.white)
                            .padding(.leading, 190)
                        Image("頭像")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 25, height: 25)
                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                            .padding(.leading, 10)
                        
                    }
                    
                    HStack {
                        UserView(name:"能量")
                        UserView(name:"好心情")
                        UserView(name:"放鬆")
                        UserView(name:"健身")
                        UserView(name:"通勤")
                        
                        
                    }
                }
                //.background(RadialGradient(gradient: Gradient(colors: [Color.yellow, Color.red]), center: .topLeading, startRadius:5, endRadius: 150))
                
                
                
                VStack(spacing: 3) {
                    
                    Text("精選入門音樂")
                        .padding(.leading, -95)
                        .padding(.top, 20)
                        .font(.system(size: 12))
                        .fontWeight(.light)
                        .foregroundColor(.gray)
                    
                    
                    HStack {
                        Image("頭像")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 40, height: 40)
                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                            .padding(.leading, 10)
                        VStack {
                            Text("瑋雪Dangerous，歡迎使")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            
                            Text("用！")
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                                .padding(.leading, -124.0) 
                        }
                        
                    }
                }
                .padding(.top, 0)
                .padding(.bottom, 10)
            }
            
            //.background(RadialGradient(gradient: Gradient(colors: [Color.blue, Color.green,Color.black]), center: .topLeading, startRadius:5, endRadius: 150))
            
            
            VStack {
                
                VStack(spacing: 50) {               
                    
                    VStack(spacing: 10) {
                        ZStack {
                            Image("Tan")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 50, height: 50)
                                .padding(.leading, 10)
                                .cornerRadius(5) 
                                .padding(.leading, -540)
                            Rectangle()
                                .frame(width: 360, height: 70)
                                .background(Color.white)
                                .cornerRadius(/*@START_MENU_TOKEN@*/6.0/*@END_MENU_TOKEN@*/)
                                .padding(.leading, 0)
                                .opacity(0.4)
                                .padding(.leading, -540)
                            
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Love Me Again")
                                    .font(.system(size: 15))
                                    .fontWeight(.bold)
                                    .foregroundColor(.white)
                                    .padding(.leading, -470)
                                
                                Text("V")
                                    .font(.footnote)
                                    .fontWeight(.regular)
                                    .foregroundColor(.gray)
                                    .padding(.leading, -470)
                                
                            }
                            Spacer()     
                            Image(systemName: "ellipsis")
                                .foregroundColor(.white)
                                .rotationEffect(Angle.init(degrees: 90))
                                .padding(.trailing, 380)
                            
                            Image(systemName: "chart.bar.fill")
                                .foregroundColor(.white)
                                .rotation3DEffect(
                                    .degrees(180),
                                    axis: /*@START_MENU_TOKEN@*/(x: 0.0, y: 1.0, z: 0.0)/*@END_MENU_TOKEN@*/)
                                .padding(.leading, -515)
                            
                            
                        }
                        
                        UserView2(icon: "SEVEN", name2: "Seven - Explicit Ver.(合作演出：\nLatto)", name3: "정국(Jung Kook)")
                        UserView2(icon: "BE", name2: "Life Goes On", name3: "防彈少年團")
                        UserView2(icon: "IU", name2: "Ending Scene", name3: "IU")
                        
                    }
                    
                    HStack {
                        Image(systemName: "backward.circle")
                            .resizable()
                            .foregroundColor(.gray)
                            .scaledToFill()
                            .frame(width: 30, height: 30)
                            .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
                            .padding(.leading, -260)
                        Text("Recap")
                            .font(.title2)
                            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                            .foregroundColor(.white)
                            .padding(.leading, -225)
                        //Spacer()
                        
                        Text("查看更多")
                            .font(.system(size: 12))
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding(.trailing, 450)
                            .padding(5)
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(Color.gray, lineWidth: 1)                    
                                
                                    .padding(.trailing, 450)
                            )
                        
                        
                        
                    }
                    
                }
                VStack(spacing: 0) {
                    
                    ZStack {
                        
                        HStack {
                            Image("Summer")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 160, height: 160)
                                .padding(.leading, -520)
                            Image("Spring")
                                .resizable()
                                .scaledToFill()
                                .frame(width: 160, height: 160)
                                .padding(.leading, -350)
                        }
                        
                        Rectangle()
                            .frame(width: 370, height: 130)
                            .background(Color.black)
                            .cornerRadius(/*@START_MENU_TOKEN@*/6.0/*@END_MENU_TOKEN@*/)
                            .padding(.leading, -540)
                            .padding(.bottom, -90)
                        //.opacity(0.4)
                        
                        VStack(spacing: 0) {
                            
                            HStack {
                                Image("Tan")
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 40, height: 40)
                                    .padding(.leading, 10)
                                    .cornerRadius(5) 
                                
                                
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("Love Me Again")
                                        .font(.system(size: 15))
                                        .fontWeight(.bold)
                                        .foregroundColor(.white)
                                    
                                    Text("V")
                                        .font(.footnote)
                                        .fontWeight(.regular)
                                        .foregroundColor(.gray)
                                        .padding(.leading, 0)
                                    
                                }
                                
                                Image(systemName: "music.note.tv")
                                    .foregroundColor(.white)
                                    .padding(.leading, 110)
                                Image(systemName: "pause.fill")
                                    .foregroundColor(.white)
                                    .padding(.leading, 10)
                                
                                
                            }
                            .padding(.leading, -540)
                            .padding(.top, 80)
                            
                            HStack{
                                Spacer().frame(width:5, height:2)
                                    .background(.white)
                                Spacer().frame(width:350, height:2)
                                    .background(Color(red:75/256, green:75/256, blue:75/256))
                            }
                            .padding(.leading, -530)
                            .padding(.top, 10)
                            
                            HStack(spacing: 40) {
                                UserView3(icon2: "house", name4:"首頁")
                                UserView3(icon2: "forward.circle", name4:"發現")
                                UserView3(icon2: "paperplane.circle", name4:"探索")
                                UserView3(icon2: "music.note.list", name4:"媒體庫")
                                UserView3(icon2: "arrowtriangle.up", name4:"升級")                            
                            }
                            .padding(.leading, -510)
                            .padding(.top, 10)
                            
                        }
                        
                        
                    }
                }
            }
            
        }
        .background(Color.black)
    }
}


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .previewLayout(.sizeThatFits)
    }
}


